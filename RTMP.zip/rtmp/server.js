const NodeMediaServer = require('node-media-server');
const fs = require('fs');

const config = {
  rtmp: {
    port: 1935,
    chunk_size: 60000,
    gop_cache: true,
    ping: 30,
    ping_timeout: 60,
  },
  http: {
    port: 8181,
    allow_origin: '*',
  },
};

fs.watchFile('C:\RTMP\rtmp\server\signal.txt', () => {
  if (fs.existsSync('C:\RTMP\rtmp\server\signal.txt')) {
    nms.close();
  } else {
const nms = new NodeMediaServer(config);
nms.run();
  }
});