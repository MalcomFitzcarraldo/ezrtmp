# RTMP


```


Requires node / node media server / flv.js
https://www.npmjs.com/package/node-media-server/v/2.6.6


http://localhost:8000/live/STREAM_NAME/index.m3u8