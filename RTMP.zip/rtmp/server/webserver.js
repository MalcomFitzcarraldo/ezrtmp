const express = require('express');
const { execFile } = require('child_process');
const path = require('path');

const app = express();
const port = 8270;

app.use(express.static('public'));

app.get('/run-script1', (req, res) => {
  execFile('python3', ['script1.py'], (error, stdout, stderr) => {
    if (error) return res.send(`Error: ${stderr}`);
    res.send(`Output: ${stdout}`);
  });
});

app.get('/run-script2', (req, res) => {
  execFile('python3', ['script2.py'], (error, stdout, stderr) => {
    if (error) return res.send(`Error: ${stderr}`);
    res.send(`Output: ${stdout}`);
  });
});

app.listen(port, () => {
  console.log(`Admin server running at http://localhost:${port}`);
});