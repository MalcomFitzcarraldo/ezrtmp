from colorama import Fore, Style, Back
import subprocess
import os
import pyperclip

#subprocess.run([r'C:/RTMP/rtmp/starter.bat'])

pyperclip.copy("~flux::C:/RTMP/rtmp/start-server.bat")

