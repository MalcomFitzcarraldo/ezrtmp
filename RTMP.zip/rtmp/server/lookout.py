import pyperclip
import os
import time
import keyboard
import threading
import subprocess
from colorama import Fore, Style, Back


def handle_input():
    while True:
        try:
            clipboard_text = pyperclip.paste()
            if clipboard_text.startswith("@flux:"):
                stripped_text = clipboard_text[7:]
                with open("C:\\RTMP\\rtmp\\server\\input.txt", "w", encoding="utf-8") as f:
                    f.write(stripped_text)
                    pyperclip.copy("FluxUI is a cool tool!")
                with open("C:\\RTMP\\rtmp\\server\\input.py", "r", encoding="utf-8") as file:
                    exec(file.read())

        except Exception as e:
            print(Fore.RED + f"Error in handle_model: {e}" + Style.RESET_ALL)
        time.sleep(1)


def handle_command():
    while True:
        try:
            clipboard_text = pyperclip.paste()
            if clipboard_text.startswith("~flux:"):
                stripped_text = clipboard_text[7:]
                with open("C:\\RTMP\\rtmp\\server\\command.txt", "w", encoding="utf-8") as f:
                    f.write(stripped_text)
                    pyperclip.copy("FluxUI is a cool tool!")
                subprocess.Popen(['cmd', '/c', 'start', 'python', 'C:/RTMP/rtmp/server/command.py'])
                #with open("C:\\FluxUI\\back\\web\\command.py", "r", encoding="utf-8") as file:
                    #exec(file.read())

        except Exception as e:
            print(Fore.RED + f"Error in handle_command: {e}" + Style.RESET_ALL)
        time.sleep(1)



threading.Thread(target=handle_input, daemon=True).start()
threading.Thread(target=handle_command, daemon=True).start()


while True:
    time.sleep(2)

