from colorama import Fore, Style, Back
import subprocess
import os
import webbrowser

#url = "C:/RTMP/server/home.html"
#webbrowser.open(url)

print(Fore.WHITE + Style.BRIGHT + Back.BLUE + "RTMP SERVER" + Style.RESET_ALL)
#subprocess.run([r'C:/FluxUI/back/clear_temp.bat'])
os.system('cls')
#subprocess.run(['cmd', '/c', 'start', 'python', 'C:/FluxUI/back/request_input.py'])
subprocess.run(["python", "C:/RTMP/rtmp/server/lookout.py"])
